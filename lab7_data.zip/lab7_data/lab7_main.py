"""
Makhai Morgan
Lab 7, accesing data in a file
Sep 29, 2025
"""
from lab7_function import *

testing()
print("\n ---- example 1: reading file -----")
